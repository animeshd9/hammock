module.exports = {
    jwksUri: "http://135.181.250.21:9011/.well-known/jwks.json",
    loginURL: "https://account.setscharts.app"
}